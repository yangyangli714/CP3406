package au.edu.jcu.cp3406.guessinggame;

import java.util.Random;

public class Game {
    // initialise a random number
    private static Random rand = new Random();

    // assign the number between 1 - 10
    private int secret = rand.nextInt(10)+1;

    public boolean check(int i){
        if (i == secret) {
            return true;
        }else {
            return false;
        }

    }

}
